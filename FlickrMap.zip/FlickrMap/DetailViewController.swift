//
//  DetailViewController.swift
//  FlickrMap
//
//  Created by Bruno Marafini on 05.12.19.
//  Copyright © 2019 eurecom. All rights reserved.
//
import UIKit

class CustomDetailViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet weak var customImageView: UIImageView!
    var customImages: NSMutableArray!
    var currentImageIndex: Int!
    
    func setupView() {
        // Update the user interface for the detail item.
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupView()
    }
    
    var detailDate: NSDate? {
        didSet {
            // Update the view.
            setupView()
        }
    }
    
    let loadingIndicator = UIActivityIndicatorView(style: .medium)
    
    func loadImage(at index: Int) {
        DispatchQueue.global(qos: .background).async {
            guard let imageURL = self.customImages.object(at: index) as? NSURL else {
                print("Invalid URL at index \(index)")
                return
            }

            guard let data = NSData(contentsOf: imageURL as URL) else {
                print("Failed to load data from URL: \(imageURL)")
                return
            }

            print("Data size: \(data.length)")
            DispatchQueue.main.async {
                if let loadedImage = UIImage(data: data as Data) {
                    self.customImageView.image = loadedImage
                } else {
                    print("Failed to create image from data")
                }
            }
        }
    }
}

