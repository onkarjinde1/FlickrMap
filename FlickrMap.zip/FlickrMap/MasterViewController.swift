import UIKit
import MapKit

class CustomMapViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var customMapView: MKMapView!
    
    var kmlParser: KMLParser!
    
    var photoURLs: [URL] = []
    
    var photoDetailController: PhotoDetailViewController? = nil
    var customAnnotations = [MKAnnotation]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.customMapView.delegate = self
        loadDataFromKML()
        setupNavigationBar()
    }
    
    private func loadDataFromKML() {
        guard let kmlURL = URL(string: "https://www.flickr.com/services/feeds/geo/vn?format=kml&page=1") else { return }
        self.kmlParser = KMLParser.parseKML(at: kmlURL)
        if let mapAnnotations = self.kmlParser?.annotations as? [MKPointAnnotation] {
            self.customMapView.addAnnotations(mapAnnotations)
            self.customMapView.showAnnotations(mapAnnotations, animated: true)
        }
    }
    
    private func setupNavigationBar() {
        navigationItem.leftBarButtonItem = editButtonItem
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let annotationView = kmlParser.annotationView(for: annotation) else { return nil }
        annotationView.canShowCallout = true
        let infoButton = UIButton(type: .infoLight)
        infoButton.addTarget(self, action: #selector(didTapInfoButton), for: .touchUpInside)
        annotationView.rightCalloutAccessoryView = infoButton
        if let imageURL = kmlParser.imageUrl(for: annotation) {
            photoURLs.append(imageURL)
        }
        return annotationView
    }
    
    @objc func didTapInfoButton(sender: UIButton) {
        self.photoDetailController = storyboard!.instantiateViewController(withIdentifier: "PhotoDetailViewController") as? PhotoDetailViewController
        guard let detailController = self.photoDetailController else { return }
        detailController.photoURLs = self.photoURLs
        self.navigationController?.pushViewController(detailController, animated: true)
        detailController.loadPhoto(from: sender.tag)
    }
}

